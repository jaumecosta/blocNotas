import os
class Opcion:

    def __init__(self, contenido):
        self.contenido = contenido
       

"""
    blog de notas de ()
    ----------------------------------
    v1.0
    ---------------------------------------------
    -----------------------------------------------
    Ejercicio 3pts para el examen final del modulo
    Sin internet
    No hay slack
    Para terminal
    Pensar bien las opciones que tendra el bloc de notas y que de tiempo a termminarlas
    Diagramacion en www.lucidchart.co (diagrama flujo)
    Entorno virtaul python 3.7.4
    git local 
    Finalizar el ejercicio a las 16:15 enviar enlace por git hub
"""
def run():
    

    opciones = input("""
        [A]brir el bloc de notas
        [L]ectura de archivo(No se puede editar)
        [B]orrar archivo
        [S]alir del programa
    """)

    if opciones == "A":
        abrir()
    elif opciones == "L":
        lectura()
    elif opciones == "B":
        notepad.delete()
    elif opciones == "S":
        salir()
    else:
        print("Te has equivocado pepona")

def abrir():

    writer = input('Escribe lo que te de la gana\n')

    with open('archivoExtra.txt', 'w') as f:
        for i in range(1):
            f.write(f'{writer}\n')

        

def lectura():
    with open('archivoExtra.txt', 'r') as f:
        for linea in f:
            print(linea)


def delete(self, contenido):
    for idx, contact in enumerate(self._contacts):
        if contact.contenido.lower() == contenido.lower():
            del self._contacts[idx]
            self._save()
            break

def salir():
    print("largo de aqui, nadie te quiere aqui")

#pregunta


if __name__ == '__main__':
    print('BLOC DE NOTAS')
    run()